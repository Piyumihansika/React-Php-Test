<?php

//establish db connection
$servername='localhost';
$username='root';
$password='';
$dbname = "Exam";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql');
}else
{ echo "";
}
//checking user entered credentials

function login() {
$request = getInstance()->request();
$data = json_decode($request->getBody());
$username='';
$password='';
try {
$db = getDB();
if(isset($_POST['username']) && isset($_POST['password']))
{
$user=htmlentities($_POST['username']);
$pass=htmlentities($_POST['password']);
$sql = "SELECT user_id, name, email, username FROM user WHERE username=:username and password=:password ";
$stmt = $db->prepare($sql);
$stmt->bindParam("username", $data->username, PDO::PARAM_STR);
$password=hash('sha256',$data->password);
$stmt->bindParam("password", $password, PDO::PARAM_STR);
$stmt->execute();
$mainCount=$stmt->rowCount();
$userData = $stmt->fetch(PDO::FETCH_OBJ);

if(!empty($userData))
{
    echo 'Login successful';
}
else
{
    echo 'Login failed';
}
}}

catch(PDOException $e) 
{
    echo '{"error":{"text":'. $e->getMessage() .'}}';
}

}
?>